package com.example.demo_resttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoResttemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
