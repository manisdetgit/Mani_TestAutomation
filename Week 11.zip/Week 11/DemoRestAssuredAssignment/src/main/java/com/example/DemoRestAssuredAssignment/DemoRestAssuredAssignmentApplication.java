package com.example.DemoRestAssuredAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRestAssuredAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRestAssuredAssignmentApplication.class, args);
	}

}
